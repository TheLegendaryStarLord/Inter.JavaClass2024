
public class Account 
{
  private double balance;
  private double rate;

  public Account()
  {
    balance = 100.00;
    rate = 0.03;
  }

  public void displayBalance()
  {
    String output = "The balance is %.2f";
    output = String.format(output, balance);
    System.out.println(output);
  }

  
  public void displayRate(){
    String output = "The rate is %.2f";
    output = String.format(output, rate);
    System.out.println(output);
  }
  
  public void deposit(double amount){
    balance += amount;
    System.out.println("Deposited: " + amount + "\nBalance: " + balance);
  }
  
  public void withdraw(double amount){
    if (amount > balance){
      System.out.println("Insufficient Funds. Withdrawal Cancelled.");
    }else{
      balance -= amount;
    }
    System.out.println("Withdrawn: " + amount + "\nBalance: " + balance);
  }
  
  public void projectInterest(int months){
    for (int i= 0; i < months; i++){
      balance = ((balance * rate)/12) + balance;
    }
    System.out.println("Projected Interest: " + balance);
  }
}
import java.util.Scanner;

public class Main {
  private static char[] alphabet;

  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);

    // Initialize the shifted array with the default alphabet
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();

    // initialize the alphabet to be used during encoding and decoding
    char[] newAlphabet = new char[alphabet.length];

    int menuchoice;
    do {
      displayMenu();
      System.out.print("Enter your choice: ");
      menuchoice = keyboard.nextInt();

      switch (menuchoice) {
        case 1:
          newAlphabet = enterKeyword(newAlphabet, keyboard);
          break;
        case 2:
          encryptMessage(newAlphabet, keyboard);
          break;
        case 3:
          decryptMessage(newAlphabet, keyboard);
          break;
        case 9:
          System.out.println("Exiting program. Goodbye!");
          break;
        default:
          System.out.println("Invalid choice. Please try again.");
      }
    } while (menuchoice != 9);
    // close keyboard once program is finished to prevent resource leak
    keyboard.close();
  }

  private static void displayMenu() {
    System.out.println("\n----- Caesar Cipher Menu -----");
    System.out.println("1. Enter Keyword");
    System.out.println("2. Encrypt Message");
    System.out.println("3. Decrypt Message");
    System.out.println("9. Quit");
  }

  // input keyword to rearrange the alphabet
  private static char[] enterKeyword(char[] newAlphabet, Scanner keyword) {
    keyword.nextLine();
    // keyword initialization
    System.out.print("Enter a keyword: ");
    String inputkeyword = keyword.nextLine().toUpperCase();

    // printing the alphabet
    System.out.println("Current Alphabet: " + String.valueOf(alphabet));

    // Copy the keyword to the temp array
    int index = 0;
    for (char ch : inputkeyword.toCharArray()) {
      if (Character.isLetter(ch) && newAlphabet[ch - 'A'] == 0) {
        newAlphabet[index++] = ch;
      }
    }

    // Fill the remaining positions in temp with the remaining alphabet letters
    for (char ch : alphabet) {
      if (!contains(newAlphabet, ch)) {
        newAlphabet[index++] = ch;
      }
    }

    // Print the new alphabet
    System.out.println("Updated Alphabet: " + String.valueOf(newAlphabet));

    return newAlphabet;
  }

  // used to check if letters in the alphabet is used yet in the new array
  private static boolean contains(char[] array, char target) {
    for (char ch : array) {
      if (ch == target) {
        return true;
      }
    }
    return false;
  }

  private static void encryptMessage(char[] newAlphabet, Scanner keyboard) {
    //to clear out the line to make sure the next input is not skipped
    keyboard.nextLine();
    System.out.print("Enter a message to encrypt: ");
    String message = keyboard.nextLine().toUpperCase();
    
    //to create the encrypted message as a string 
    StringBuilder encryptedMessage = new StringBuilder();

    //to encrypt the message by checking each character in the message
    for (char c : message.toCharArray()) {
      if (Character.isLetter(c)) {
        int index = c - 'A';
        // Check if the index is within the bounds of the newAlphabet array
        if (index >= 0 && index < newAlphabet.length) {
          encryptedMessage.append(newAlphabet[index]);
        } else {
          System.out.println(c + " is not a letter in the updated alphabet.");
        }
      } else {
        encryptedMessage.append(c);
      }
    }
    //gives encrypted message
    System.out.println("Encrypted message: " + encryptedMessage.toString());
  }

  private static void decryptMessage(char[] newAlphabet, Scanner keyboard) {
    //clears line to not skip the next input
    keyboard.nextLine();

    //to get the encrypted message
    System.out.print("Enter the message to decrypt: ");
    String encryptedMessage = keyboard.nextLine().toUpperCase();
    StringBuilder decryptedMessage = new StringBuilder();

    //to decrypt the message by checking each character in the message
    for (char ch : encryptedMessage.toCharArray()) {
      if (Character.isLetter(ch)) {
        int index = newAlphabet.length - 1;
        while (newAlphabet[index] != ch) {
          index--;
        }
        decryptedMessage.append(alphabet[index]);
      } else {
        decryptedMessage.append(ch);
      }
    }

    System.out.println("Decrypted Message: " + decryptedMessage.toString());
  }
}

/* CS 282 Intermediate Java  Spring 2023
 * Cuyamaca College
 * Adam Sanchez
 * Lab 5
 * 
 */
import java.util.Scanner;
import java.util.Queue;
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        Scanner key = new Scanner(System.in);
        Queue<String> Waitlist = new LinkedList<String>();
        boolean menu = true;

        while (menu) {
            System.out.println("\n/\\/\\/\\/\\/\\ DMV Menu /\\/\\/\\/\\/\\");
            System.out.println("1. Add a person");
            System.out.println("2. Check who is next in line");
            System.out.println("3. Assist person (and remove)");
            System.out.println("4. Quit menu");

            System.out.print("\nEnter your choice (1-4): ");
            int choice = key.nextInt();
            key.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter the full name you'd like to add: ");
                    String name = key.nextLine();
                    Waitlist.add(name);
                    System.out.println(name + " has been added to the line.");
                    break;
                case 2:
                    if (!Waitlist.isEmpty()) {
                        System.out.println("The next person in line is " + Waitlist.peek());
                    } else {
                        System.out.println("The line is empty.");
                    }
                    break;
                case 3:
                    if (!Waitlist.isEmpty()) {
                        String nextPerson = Waitlist.poll();
                        System.out.println(nextPerson + " has been assisted.");
                    } else {
                        System.out.println("The line is empty.");
                    }
                    break;
                case 4:
                    System.out.println("Exiting program...");
                    menu = false;
                    key.close();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}

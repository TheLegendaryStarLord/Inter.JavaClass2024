import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    System.out.println("Enter a number: ");
    int n = keyboard.nextInt();

    System.out.println("Sum of digits: " + SumOfDigits(n) );

    keyboard.close();
  }

  // @Test
  private static int SumOfDigits(int n) {
    if (n < 10){
      return n;
    }
    return  n % 10 + SumOfDigits(n / 10);
  }
}

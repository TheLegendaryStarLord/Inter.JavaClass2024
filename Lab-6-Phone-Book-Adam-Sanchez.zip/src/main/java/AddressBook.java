import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class AddressBook {
  private ArrayList<Contact> personContainer;
  private int currentPosition;

  public AddressBook() {
    personContainer = new ArrayList<Contact>();
    currentPosition = -1;
  }

  public void addContact(Contact contact) {
    personContainer.add(contact);
  }

  public void deleteContact(Contact contact) {
    personContainer.remove(contact);
  }

  public Contact findContact(String lastName) {
    int containerLength = personContainer.size();
    for (int i = 0; i < containerLength; i++) {
      if (personContainer.get(i).getLastName().contains(lastName)) {
        currentPosition = i;
        return personContainer.get(i);
      }
    }
    return null; // Contact not found
  }

  public void editContact(String lastName, String newFirstName, String newLastName, String newAddress,
      String newPhoneNumber) {
    Contact contactToEdit = personContainer.get(currentPosition);
    if (contactToEdit != null) {
      contactToEdit.setFirstName(newFirstName);
      contactToEdit.setLastName(newLastName);
      contactToEdit.setAddress(newAddress);
      contactToEdit.setPhoneNumber(newPhoneNumber);
      System.out.println("Contact updated successfully.");
    } else {
      System.out.println("Contact not found.");
    }
  }

  public void getCurrent() {
      if (currentPosition >= 0 && currentPosition < personContainer.size()) {
          System.out.println("Currently placed at location: " + currentPosition);
          System.out.println(personContainer.get(currentPosition));
      } else {
          System.out.println("No contact selected.");
      }
  }

  public void sortContactsByLastName() {
      if (personContainer.size() > 1) { // Check if there are more than one contact
          Collections.sort(personContainer, new Comparator<Contact>() {
              @Override
              public int compare(Contact c1, Contact c2) {
                  String lastName1 = c1.getLastName().toUpperCase();
                  String lastName2 = c2.getLastName().toUpperCase();
                  return lastName1.compareTo(lastName2);
              }
          });
      }
  }
  
  public void displaySortedContacts() {
      int containerLength = personContainer.size();
      if (containerLength == 0) {
          System.out.println("No contacts to display.");
      } else {
          System.out.println("Sorted Contacts:");
          sortContactsByLastName(); // Ensure contacts are sorted before display
          for (int i = 0; i < containerLength; i++) {
              System.out.println(personContainer.get(i));
          }
      }
  }


  public void clearContacts() {
    personContainer.clear();
  }
}

/* CS 282 Intermediate Java  Spring 2023
 * Cuyamaca College
 * Adam Sanchez
 * Lab 6
 * 
 */

import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    AddressBook addressBook = new AddressBook();

    while (true) {
      System.out.println("\nMain Menu:");
      System.out.println("1. Add Contact");
      System.out.println("2. Find Contact (based on last name) (changes current position)");
      System.out.println("3. Edit Contact (searches based on last name)");
      System.out.println("4. Delete Contact (also searches on last name)");
      System.out.println("5. Display Current Contact (based on current position)");
      System.out.println("6. Sort and Display Contacts (sorts by last name)");
      System.out.println("7. Exit");

      System.out.print("Enter your choice: ");
      int choice = keyboard.nextInt();
      keyboard.nextLine(); // Consume newline

      switch (choice) {
        case 1:
          System.out.print("Enter first name: ");
          String firstName = keyboard.nextLine();
          System.out.print("Enter last name: ");
          String lastName = keyboard.nextLine();
          System.out.print("Enter address: ");
          String address = keyboard.nextLine();
          System.out.print("Enter phone number: ");
          String phoneNumber = keyboard.nextLine();
          Contact newContact = new Contact(firstName, lastName, address, phoneNumber);
          addressBook.addContact(newContact);
          addressBook.sortContactsByLastName(); // Sort after adding a contact
          break;
        case 2:
          System.out.print("Enter last name to find: ");
          String findLastName = keyboard.nextLine();
          Contact foundContact = addressBook.findContact(findLastName);
          if (foundContact != null) {
            System.out.println("Contact Found: " + foundContact.toString());
          } else {
            System.out.println("Contact not found.");
          }
          break;
        case 3:
          System.out.print("Enter last name of contact to edit: ");
          String editLastName = keyboard.nextLine();
          System.out.print("Enter new first name: ");
          String newFirstName = keyboard.nextLine();
          System.out.print("Enter new last name: ");
          String newLastName = keyboard.nextLine();
          System.out.print("Enter new address: ");
          String newAddress = keyboard.nextLine();
          System.out.print("Enter new phone number: ");
          String newPhoneNumber = keyboard.nextLine();
          addressBook.editContact(editLastName, newFirstName, newLastName, newAddress, newPhoneNumber);
          addressBook.sortContactsByLastName();
          break;
        case 4:
          System.out.print("Enter the last name of the contact to delete: ");
          String deleteLastName = keyboard.nextLine();
          Contact contactToDelete = addressBook.findContact(deleteLastName);
          if (contactToDelete != null) {
            addressBook.deleteContact(contactToDelete);
            System.out.println("Contact deleted successfully.");
            addressBook.sortContactsByLastName();
          } else {
            System.out.println("Contact not found.");
          }
          break;
        case 5:
          addressBook.getCurrent();
          break;
        case 6:
          addressBook.displaySortedContacts();
          break;
        case 7:
          System.out.println("Exiting program.");
          keyboard.close();
          System.exit(0);
        default:
          System.out.println("Invalid choice. Please try again.");
      }
    }
  }
}
